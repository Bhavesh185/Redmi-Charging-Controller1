package com.example.redmichargingcontroller

import android.app.Activity
import android.os.BatteryManager
import android.os.Bundle
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var batteryManager: BatteryManager
    private lateinit var statusText: TextView
    private lateinit var sourceText: TextView
    private lateinit var levelText: TextView
    private lateinit var voltageText: TextView
    private lateinit var currentText: TextView
    private lateinit var powerText: TextView
    private lateinit var healthText: TextView
    private lateinit var noteText: TextView

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null) updateBattery(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        batteryManager = getSystemService(BATTERY_SERVICE) as BatteryManager
        buildScreen()
        val sticky = registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (sticky != null) updateBattery(sticky)
    }

    override fun onDestroy() {
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) { }
        super.onDestroy()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 32)
            setBackgroundColor(0xFFF4F6FA.toInt())
        }
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "Redmi Charging Controller"
            textSize = 24f
            setTextColor(0xFF172033.toInt())
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "Live charging information · Read-only monitor"
            textSize = 14f
            setTextColor(0xFF586174.toInt())
            setPadding(0, 6, 0, 22)
        }
        root.addView(subtitle)

        statusText = addCard(root, "Charging status", "Reading battery…", 22f)
        sourceText = addCard(root, "Power source", "—", 18f)
        levelText = addCard(root, "Battery level", "—", 18f)
        voltageText = addCard(root, "Battery voltage", "—", 18f)
        currentText = addCard(root, "Battery current", "—", 18f)
        powerText = addCard(root, "Estimated battery power", "—", 18f)
        healthText = addCard(root, "Battery health", "—", 18f)

        noteText = TextView(this).apply {
            text = "Turbo Charge note\nThis app cannot activate or unlock Mi Turbo Charge. Fast charging depends on the phone's charging hardware, charger protocol and cable. Android may also hide some charging details, so readings can be unavailable or approximate."
            textSize = 14f
            setTextColor(0xFF39445A.toInt())
            setPadding(4, 18, 4, 8)
        }
        root.addView(noteText)
        setContentView(scroll)
    }

    private fun addCard(parent: LinearLayout, heading: String, value: String, valueSize: Float): TextView {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(0xFFFFFFFF.toInt())
            val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            params.bottomMargin = 12
            layoutParams = params
        }
        val label = TextView(this).apply {
            text = heading
            textSize = 13f
            setTextColor(0xFF687286.toInt())
        }
        val valueView = TextView(this).apply {
            text = value
            textSize = valueSize
            setTextColor(0xFF172033.toInt())
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 5, 0, 0)
        }
        card.addView(label)
        card.addView(valueView)
        parent.addView(card)
        return valueView
    }

    private fun updateBattery(intent: Intent) {
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val percent = (level * 100f / scale).toInt()
        val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
        val health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)

        val statusLabel = when (status) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
            BatteryManager.BATTERY_STATUS_FULL -> "Full"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
            else -> "Unknown"
        }
        val source = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_USB -> "USB power"
            BatteryManager.BATTERY_PLUGGED_AC -> "AC power adapter"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless power"
            0 -> "Not connected"
            else -> "Other / unknown"
        }

        val currentUa = try { batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) } catch (_: Exception) { 0 }
        val currentMa = abs(currentUa) / 1000.0
        val voltageV = voltageMv / 1000.0
        val watts = if (voltageMv > 0 && currentUa != Int.MIN_VALUE && currentUa != 0) {
            voltageV * (abs(currentUa) / 1_000_000.0)
        } else null

        statusText.text = "$statusLabel · $percent%"
        sourceText.text = source
        levelText.text = "$percent%"
        voltageText.text = if (voltageMv > 0) String.format(Locale.getDefault(), "%.2f V", voltageV) else "Unavailable"
        currentText.text = if (currentUa != 0) String.format(Locale.getDefault(), "%.0f mA (battery reading)", currentMa) else "Unavailable on this device"
        powerText.text = watts?.let { String.format(Locale.getDefault(), "%.2f W (approx.)", it) } ?: "Unavailable"
        healthText.text = when (health) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheating"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            else -> "Unknown / not reported"
        }
    }
}
