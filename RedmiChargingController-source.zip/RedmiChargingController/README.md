# Redmi Charging Controller (starter Android project)

A read-only Android battery/charging monitor for Redmi Note 9 Pro Max and other Android devices.

## What it does
- Shows charging state and battery percentage.
- Shows Android-reported power source (USB / AC / wireless).
- Reads battery voltage and, where exposed by the device, battery current.
- Estimates battery-side power from voltage × current. This is not a USB input power meter and may differ from the charger's advertised wattage.
- Shows Android-reported battery health.

## Important limitation
This app does **not** change charging voltage/current, negotiate USB-PD or Qualcomm Quick Charge, enable Xiaomi Mi Turbo Charge, or bypass charger authentication. Those functions depend on the phone's charging IC, firmware, charger and cable. Do not use kernel tweaks or unofficial charging overrides to force unsupported modes.

## Build the APK
1. Install Android Studio (with Android SDK Platform 35) on a computer.
2. Open this folder in Android Studio.
3. Let Gradle sync. Use JDK 17.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

The project is source code, not a prebuilt APK. Building requires Android SDK/Gradle on a computer.
